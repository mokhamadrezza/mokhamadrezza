package com.erzha.erzhasubmission

class Company (
    var name: String = "",
    var detail: String = "",
    var image: Int = 0

)
