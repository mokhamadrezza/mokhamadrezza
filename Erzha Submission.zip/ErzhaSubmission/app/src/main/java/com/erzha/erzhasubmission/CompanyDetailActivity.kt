package com.erzha.erzhasubmission

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class CompanyDetailActivity: AppCompatActivity(), View.OnClickListener {

    companion object {
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_DETAIL = "extra_detail"
        const val EXTRA_IMG = "extra_image"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.item_row_company)

        val setActionBar = supportActionBar
        setActionBar?.title = "Detail Perusahaan"
        setActionBar?.setDisplayHomeAsUpEnabled(true)

        val displaySetName: TextView = findViewById(R.id.tv_item_name)
        val displaySetDetails: TextView = findViewById(R.id.tv_item_detail)
        val imageItemPhoto: ImageView = findViewById(R.id.img_item_photo)

        val companyName = intent.getStringExtra(EXTRA_NAME)
        val companyDetail = intent.getStringExtra(EXTRA_DETAIL)
        val companyPhoto = intent.getIntExtra(EXTRA_IMG, 0)

        Glide.with(this)
            .load(companyPhoto)
            .apply(RequestOptions())
            .into(imageItemPhoto)
        displaySetName.text = companyName
        displaySetDetails.text = companyDetail

    }

    override fun onClick(v:View) {
        when(v.id) {
            R.id.tv_item_detail -> Toast.makeText(this, "Anda Memilih Detail Perusahaan ", Toast.LENGTH_SHORT).show()
            R.id.img_item_photo -> Toast.makeText(this, "Anda Memilih Gambar Perusahaan ", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}