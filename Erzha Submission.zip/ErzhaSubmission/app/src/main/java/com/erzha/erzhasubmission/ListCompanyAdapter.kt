package com.erzha.erzhasubmission

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class ListCompanyAdapter(private val listCompany: ArrayList<Company>) : RecyclerView.Adapter<ListCompanyAdapter.ListViewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        var tvDetail: TextView = itemView.findViewById(R.id.tv_item_detail)
        var imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback

    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Company)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_row_company, viewGroup, false)
            return ListViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listCompany.size
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val company = listCompany[position]

        Glide.with(holder.itemView.context)
            .load(company.image)
            .apply(RequestOptions().override(55, 55))
            .into(holder.imgPhoto)

        holder.tvName.text = company.name
        holder.tvDetail.text = company.detail


        val thisActivityContext: Context = holder.itemView.context
        holder.itemView.setOnClickListener {
            Toast.makeText(holder.itemView.context, "Anda Pilih " + listCompany[position].name, Toast.LENGTH_SHORT).show()
        }
    }
}