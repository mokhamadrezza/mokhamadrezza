package com.erzha.erzhasubmission

object CompanyData {
    private val companyNames = arrayOf(
        "Telkom Indonesia",
        "Telkom Akses",
        "Telkomsel",
        "Telkomsat",
        "Telkom Metra",
        "Telin",
        "Telkom Infra",
        "Pins",
        "Mitratel",
        "Metranet"
    )

    private val companyDetail = arrayOf(
        "Pada tahun 1882, didirikan sebuah badan usaha swasta penyedia layanan pos dan telegraf. Layanan komunikasi kemudian dikonsolidasikan oleh Pemerintah Hindia Belanda ke dalam jawatan Post Telegraaf Telefoon (PTT). Sebelumnya, pada tanggal 23 Oktober 1856, dimulai pengoperasian layanan jasa telegraf elektromagnetik pertama yang menghubungkan Jakarta (Batavia) dengan Bogor (Buitenzorg). Pada tahun 2009 momen tersebut dijadikan sebagai patokan hari lahir Telkom." +
                "PT Telkom Indonesia (Persero) Tbk, biasa disebut Telkom Indonesia atau Telkom saja (IDX: TLKM, NYSE: TLK) adalah perusahaan informasi dan komunikasi serta penyedia jasa dan jaringan telekomunikasi secara lengkap di Indonesia. Telkom mengklaim sebagai perusahaan telekomunikasi terbesar di Indonesia, dengan jumlah pelanggan telepon tetap sebanyak 15 juta dan pelanggan telepon seluler sebanyak 104 juta." +
                "Telkom merupakan salah satu BUMN yang 52,09% sahamnya saat ini dimiliki oleh Pemerintah Indonesia, dan 47,91% dimiliki oleh publik. Telkom juga menjadi pemegang saham mayoritas di 13 anak perusahaan, seperti PT Telekomunikasi Seluler (Telkomsel), PT Telkom Akses, PT Multimedia Nusantara (TelkomMetra), PT PINS Indonesia (PINS)",
        "We build a fiber optic network and bring internet connection to your properties by deploying 30 terra route nodes and approximately 8.500+ km of fiber optic cable." +
                "We support your fiber to the home connection as well as backbone network for your broadband wireless connection." +
                "What we do for you: Network Planning & Inventory with Latest Technology, We bring high-speed internet for you & your family, And Manage network availibility & maintain customer experience",
        "PT Telekomunikasi Selular, atau dikenal dengan sebutan Telkomsel, adalah salah satu perusahaan operator telekomunikasi seluler di Indonesia. Saat ini Telkomsel menjadi operator telekomunikasi seluler terbesar di Indonesia yang mengoperasikan 236 ribu BTS (Base Tranceiver Station) dan melayani lebih dari 170 juta pelanggan, membuat Telkomsel mengambil pangsa pasar telekomunikasi seluler Indonesia hampir sebesar 60% di tahun 2020. Dengan capaian tersebut, Telkomsel menjadi operator terbesar keenam di dunia yang melayani ratusan juta pelanggan dalam satu negara. Bekerja sama dengan 575 mitra roaming, layanan Telkomsel saat ini dapat digunakan di 200 negara di dunia." +
                "Pada tahun 1993, PT Telkom mulai merambah teknologi nirkabel GSM, pada tahun selanjutnya PT Satelit Palapa Indonesia operator jaringan GSM pertama di Indonesia yang mengeluarkan kartu SIM muncul. PT Telkomsel kemudian didirikan bersama Indosat pada tahun 1995 dan meluncurkan kartu Halo pada tanggal 26 Mei 1995 sebagai layanan paska bayar." +
                "Kepemilikan Telkomsel saat ini dipegang oleh Telkom Indonesia sebesar 65%, dan Singapore Telecommunications Singapura 35%.",
        "PT. Patra Telekomunikasi Indonesia atau Patrakom (sejak 2018 berubah identitas menjadi Telkomsat) adalah perusahaan yang bergerak di bidang jasa layanan telekomunikasi satelit dan terestrial. Patrakom menyediakan telekomunikasi yang diperuntukkan bagi perusahaan-perusahaan, bukan untuk publik. Patrakom juga merupakan perusahaan penyelenggara telekomunikasi jaringan tertutup. Patrakom berdiri pada tahun 1995. Layanannya mencakup telekomunikasi seperti jaringan komunikasi data, suara, video, multimedia dan internet berdasarkan satelit. Saat ini Patrakom telah memiliki lisensi dalam bidang Penyelenggaraan jaringan tetap tertutup, penyelenggaraan jasa akses internet, Network Access Poin (NAP), penyelenggaraan jasa interkoneksi, dan SISKOMDAT atau penyelenggaraan jasa Sistem Komunikasi Data." +
                "Pada tahun 2013, PT Telekomunikasi Indonesia Tbk (Telkom) mengukuisisi saham Patrakom sebanyak 80% untuk masuk ke pasar maritim broadband. Sejak bermitra bersama Telkom, Patrakom memanajemen bisnis satelit broadband yang difokuskan pada minyak, gas dan pertambangan industri, satelit kelautan dan perkebunan." +
                "Patrakom juga bermitra dengan produsen peralatan telekomunikasi lain untuk melayani berbagai kebutuhan perusahaan-perusahaan dalam bidang: 1. Minyak & Pertambangan Telekomunikasi (Telekomunikasi Seluler Operator), 2. Lembaga Keuangan Perbankan & (sistem on-line), 3. Media Informasi (siaran pencetakan jarak jauh), 4. Perkebunan pariwisata Pemerintah (Departemen) maritim.",
        "PT Multimedia Nusantara (disingkat METRA), adalah perusahaan Indonesia yang didirikan sejak tahun 2003. Merupakan anak perusahaan dari Telkom Indonesia dengan mayoritas sahamnya sebesar 100% dikuasai oleh Telkom." +
                "METRA diposisikan oleh Telkom sebagai Strategic Investment Company dengan tujuan untuk memperkuat pilar bisnis new wave Telkom yang fokus pada industri Informasi, Media dan Edutaintment (IME). Posisi ini menjadikan METRA menerapkan strategi bertumbuh dengan cara Capture dan Nurture. Strategi Capture dilakukan untuk mempersingkat waktu penyediaan portofolio dan strategi Nurture dilakukan dengan pertimbangan bahwa tidak ada perusahaan sejenis di pasar dan METRA Group memiliki sumber daya yang dibutuhkan untuk mengembangkan bisnis tersebut. Portofolio bisnis yang dikelola METRA Group sampai dengan tahun 2009 terdiri dari: Satellite Data Access Services, e-Payment, Application Services, IT Managed Service, System Integration, Software Development, e-Commerce, Content, Contact Center, Directory Services, Pay Televisi dan akan terus bertumbuh seiring dengan aksi korporasi yang dilakukan METRA.",
        "TELIN atau PT. Telekomunikasi Indonesia Internasional adalah sebuah perseroan tertutup yang bergerak dalam bidang telekomunikasi. PT Telekomunikasi Indonesia International didirikan pada tahun 1995 dan berbasis di Jakarta, Indonesia. TELIN sebelumnya dikenal sebagai PT AriaWest International dan berubah nama menjadi PT Telekomunikasi Indonesia International pada Maret 2007. TELIN merupakan anak perusahaan dari Telkom Indonesia, sebuah perusahaan telekomunikasi dan penyedia jaringan milik negara. Selain di Indonesia, Perusahaan ini memiliki anak cabang yang beroperasi di Singapura, Hong Kong, dan Malaysia." +
                "Telin melayani layanan operator internasional dan investasi di bisnis telekomunikasi internasional serta berfungsi sebagai lengan bisnis Telkom dalam mengelola dan mengembangkan lini bisnisnya di luar negeri. Saat ini Telin memiliki 8 anak perusahaan yaitu Telin Singapore, Telin Hong-Kong, Telin Timor-Leste dengan produk yang disebut Telkomcel, Telkom Australia, Telin Malaysia, Telkom Macau, Telkom Taiwan, Telkom Amerika Serikat, dan cabang di Myanmar. Telekomunikasi Indonesia International, melalui anak perusahaannya, menyediakan komunikasi informasi dan layanan jaringan internasional. Menawarkan layanan suara dan menyediakan layanan data, termasuk bandwidth internasional, transit IP global, data center, dan layanan CDN. Selain itu, ia beroperasi sebagai kontak pusat penyedia jasa outsourcing di Malaysia",
        "Telkom Infra adalah anak usaha induk (subholding) milik PT Telkom Indonesia (Telkom Group) yang bergerak khusus di bidang jasa infrastruktur. Dibentuk pada 23 Januari 2014, anak usaha induk ini membawahi PT Dayamitra Telekomunikasi (Mitratel), PT Telkom Akses, dan PT Graha Sarana Duta (Telkom Properti). Pembentukan Telkom Infra juga merupakan strategi penataan dan optimalisasi anak perusahaan Telkom Indonesia. Direktur utama perusahaan ini hingga pada tahun 2015 adalah Edy Irianto. Alamat perusahaan terletak di Mugi Griya Building, 5th Floor Jl. MT Haryono Kav.10 Jakarta.",
        "PINS berdiri sejak tanggal 17 Oktober 1995 dengan nama PT. Pramindo Ikat Nusantara. Pada awalnya fokus bisnis Perseroan adalah untuk menyelenggarakan Kerja Sama Operasi (KSO) telekomunikasi di wilayah Sumatra.Pada tahun 2002, saham Perseroan seluruhnya diambil alih oleh PT. Telekomunikasi Indonesia Tbk (TELKOM), sebuah perusahaan telekomunikasi terbesar di Indonesia, dan mengacu pada CSS TELKOM maka mulai Oktober 2010 Perseroan memfokuskan diri pada portofolio Premise Integration Service. Perubahan nama perusahaan dari PT. Pramindo Ikat Nusantara menjadi PT. PINS INDONESIA ini dikukuhkan tanggal 20 Desember 2012.Pada tahun 2016, PINS Indonesia adalah perusahaan yang aktif dalam bisnis integrasi perangkat, jaringan, sistem dan proses menggunakan konsep Internet of Things (IoT) dengan kemampuan sumber daya manusia dan kapabilitas kesisteman yang terbaik. PINS Indonesia mempunyai tagline “The IoT Company”." +
                "PINS atau PT PINS INDONESIA adalah anak perusahaan dari PT Telekomunikasi Indonesia yang bergerak di bidang Internet of Things (IoT). Berdiri pada tahun 1995, PINS memiliki pengalaman di bidang telekomunikasi selama lebih dari 20 tahun yang memposisikan perseroan sebagai perusahaan penyedia sarana dan prasarana layanan telekomunikasi terlengkap dan tepercaya di seluruh Nusantara. PINS Indonesia memiliki 3 bisnis portfolio yaitu IoT Service, Mobility Service, dan CPE Manage Service. Hingga pada tahun 2015, mitra bisnis PINS di antaranya adalah Cisco, HP, Samsung, ZTE, Huawei, LG, dan Palo Alto. Dari jajaran Direksi saat ini PINS Indonesia dipimpin oleh Muhammad Firdaus sebagai CEO.",
        "PT. Dayamitra Telekomunikasi (Mitratel) adalah salah  satu  anak  perusahaan PT Telkom Indonesia (Persero)  Tbk  yang  bergerak di bidang penyediaan infrastruktur telekomunikasi. Mitratel mulai menapaki bisnis menara telekomunikasi sejak tahun 2008. Sampai saat ini, Mitratel telah mengelola lebih dari 22.000 menara telekomunikasi yang tersebar di seluruh Indonesia. Semua operator seluler Indonesia telah menjadi tenant dengan menempatkan perangkat BTSnya di menara Mitratel.",
        "Metranet adalah anak perusahaan PT. Telekomunikasi Indonesia, Tbk (Telkom) yang dibentuk sejak 17 April 2009 yang memiliki visi dalam memonetisasi peluang pada industri online. Dalam perkembangannya, berbagai inisiatif bisnis telah dilakukan, seperti: mobile content, commerce, online ticketing, dan social network game publishers." +
                "Pada tanggal 17 November 2011, Metranet memulai memulai babak baru dengan melakukan kerjasama strategis dengan Microsoft, menghadirkan media online PlasaMSN (umsn.co.id). Memasuki tahun 2012 Metranet kembali menginisiasi kerjasama dengan eBay. Sebagai hasilnya, pada tanggal 17 September 2012 kerjasama dengan eBay direalisasikan dengan membentuk perusahaan patungan (Joint Venture) dengan nama PT Metraplasa (Sekarang adalah Blanja.com)." +
                "Pada tahun 2015, Metranet konsisten pada 2 (dua) portfolio bisnis yaitu Digital Consumer Payment (Upoint) dan Digital Advertising (Uad). Dengan mengusung tema “Being Alive” serta focus dan control pada Restructuring Plan tahun 2015, di awal tahun 2016 Metranet meletakkan fundamental bisnis di industri game dengan bekerja sama industri game global (Garena, Dota, dll) serta mengawali media online Uzone.id."
    )

    private val companyImages = intArrayOf(
        R.drawable.logotelkom,
        R.drawable.telkomakses,
        R.drawable.telkom_sel,
        R.drawable.telkom_sat,
        R.drawable.telkom_metra,
        R.drawable.telkom_inter,
        R.drawable.telkom_infra,
        R.drawable.pins_idn,
        R.drawable.mitratel,
        R.drawable.metra_net
    )

    val listData: ArrayList<Company>
        get() {
            val list = arrayListOf<Company>()
            for (position in companyNames.indices) {
                val company = Company()
                company.name = companyNames[position]
                company.detail = companyDetail[position]
                company.image = companyImages[position]
                list.add(company)
            }

            return list
        }
}